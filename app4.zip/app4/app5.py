from flask import Flask, redirect, url_for, session, request
from flask_oauth import OAuth


SECRET_KEY = 'development key'
DEBUG = True
FACEBOOK_APP_ID = '523906521071451'
FACEBOOK_APP_SECRET = '52390ed14105dcc3c0414cdc7ef69893'


app = Flask(__name__)
app.debug = DEBUG
app.secret_key = SECRET_KEY
oauth = OAuth()

facebook = oauth.remote_app('facebook',
    base_url='http://rommies.netne.net/',
    request_token_url=None,
    access_token_url='/oauth/access_token',
    authorize_url='http://rommies.netne.net/',
    consumer_key=FACEBOOK_APP_ID,
    consumer_secret=FACEBOOK_APP_SECRET,
    request_token_params={'scope': 'email'}
)

print "si"

@app.route('/')
def index():

    print"no"
    return redirect(url_for('login'))


@app.route('/login')
def login():

    print "hola"
    return facebook.authorize(callback=url_for('facebook_authorized',
        next=request.args.get('next') or request.referrer or None,
        _external=True))



@app.route('/login/authorized')
@facebook.authorized_handler
def facebook_authorized(resp):
    if resp is None:
        return 'Access denied: reason=%s error=%s' % (
            request.args['error_reason'],
            request.args['error_description']
        )
    session['oauth_token'] = (resp['access_token'], '')
    me = facebook.get('/me')
    print "hello"
    return 'Logged in as id=%s name=%s redirect=%s' % \
        (me.data['id'], me.data['name'], request.args.get('next'))



@facebook.tokengetter
def get_facebook_oauth_token():
    return session.get('oauth_token')
    print "d"



if __name__ == '__main__':
    app.run()






