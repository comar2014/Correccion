import sys
reload(sys)
sys.setdefaultencoding("utf-8")

from flask import Flask, redirect, url_for, request, render_template

app = Flask(__name__)


@app.route('/')
@app.route('/inicio')
def inicio():
    #return render_template('rest.manager.htm')
    return render_template('face1.html')
    

@app.route('/consultar/restaurantes')
def consulta_restaurantes():
    return render_template('rest.manager.consulta.restaurantes.htm')

@app.route('/consultar/platillos')
def consulta_platillos():
    return render_template('rest.manager.consulta.platillos.htm')


@app.route('/mantenimiento/restaurantes')
def mantenimiento_restaurantes():
    return render_template('rest.manager.mantenimiento.restaurantes.htm')
    

@app.route('/mantenimiento/platillos')
def mantenimiento_platillos():
    return render_template('rest.manager.mantenimiento.platillos.htm')
    
@app.route('/informacion')
def informacion():
    return render_template('rest.manager.informacion.htm')

@app.route('/agregar_apartamento', methods=['POST'])
def agregar_restaurante():

    titulo_local = 'Apartamentos'
    mensaje_insercion= ''
    nombre = request.form['inputNombre_aparta']
    descripcion = request.form['inputDescripcion']
    facilidades = request.form['inputFacilidades']
    caracteristicas = request.form['inputCaracteristicas']
    ubicacion = request.form['inputUbicacion']
    precio = request.form['inputPrecio']
    telefono = request.form['inputTelefono']
    correo = request.form['inputCorreo']
    
    try:
	apartamento1= Apartamento()
	print "si"
	apartamento1.Publica_Apartamento(nombre,descripcion,facilidades,caracteristicas,ubicacion,precio,telefono,correo)
	print "si"
        #EscrituraArchivo(nombre,tipo,ubicacion,telefono,horario)
        #return render_template('resultado_insercion.html', titulo = titulo_local, mensaje = mensaje_insercion)

    except:
        mensaje_insercion = 'No se pudo agregar el apartamento'
        
    else:
        mensaje_insercion = 'El apartamento ha sido ingresado con exito'
        return render_template('resultado_insercion.html', titulo = titulo_local, mensaje = mensaje_insercion)

class  Apartamento:

      
    def __init__(self): # Constructor para  la publicacion de apartamentos 
        self.Titulo=  ""
        self.Descripcion= ""
        self.Facilidades= ""
        self.Caracteristicas=""
        self.Ubicacion= ""
        self.Precio= ""
        self.Telefono= ""
        self.Correo= ""
        self.lista=[]
        self.lista=self.leer_Archivo()
        


    def crear_Archivo(self):
        archi=open('Apartamentos.txt','a')
        archi.close()
        

	# Metodo que permite recibir las variables del html para escibirlas en un archivo, y si permitir la publicacion del apartamento
    def Publica_Apartamento(self,titulo, descripcion,facil,caract,ubi,pre,tel, email): 
		    
		  #  Facilidades= []
		    print("Ingrese los datos del apartamento que desea publicar\n")
		    self.Titulo= titulo
		    self.Descripcion= descripcion
		    self.Facilidades= facil
		    self.Caracteristicas= caract
		    self.Ubicacion= ubi
		    self.Precio= pre
		    self.Telefono= tel
		    self.Correo= email
		    Archivito=open('Apartamentos.txt','a')
		    Archivito.write(str(self.Titulo).lower() + ";" + str(self.Descripcion).lower()+ ";"+  str(self.Facilidades).lower() + ";" +  str( self.Caracteristicas)  + ";" + str(self.Ubicacion).lower() + ";" + str(self.Precio).lower() + ";" + str(self.Telefono).lower() + ";" + str(self.Correo).lower())
		    Archivito.write("\n")
		    print("\n")
		    print("Los datos del apartamento se han ingresado exitosamente\n")
		    Archivito.close()
 #***********************************************************************************************
    # Se encarga de leer el archivo en donde se encuentran los datos del 

    def leer_Archivo(self):

        archi=open('Apartamentos.txt','r') 
        self.listaFacilidades=[]
        self.listaCaracteristicas=[]
        linea=archi.readlines() # Lista que contiene todas las lineas del archivo.    

        for li in linea:
     
           elimina=li.strip("\n") # elimina el salto de linea 
           y=elimina
           self.lista= self.lista + [self.lista.append([str(y)])]
         
        archi.close()
        self.lista= list(filter(None,self.lista))
        return self.lista
     
# Realiza la busqueda ya sea por cacteristica o facilidad
    def busqueda_Facilidades(self, facilidad):
        resultados=[]
        for  apartamento in  self.lista: # Recorre la lista estan todos los apartamentos
            for elem in apartamento: # recorre las sublistas de la lista 
                if facilidad in elem: # compara  elementos
                    resultados.append(apartamento)
                    
        if resultados==[]:
            print("No hay resultados")
         
        return resultados


    def busqueda_Precio(self, precio, mayor_menor):
        resultados=[]
        for  apartamento in  self.lista:# Recorre la lista estan todos los apartamentos
           ls_apartamento=apartamento[0].split(";") # Separa el string y lo convierte en lista
           if mayor_menor== "<":
                if float(precio) >= float(ls_apartamento[5]):
                    resultados.append(apartamento)#lista que contiene los apartamentos con los precios 
           else:
                if float(precio) < float(ls_apartamento[5]):
                    resultados.append(apartamento)

        if resultados==[]:
            print("No hay resultados")
        else:
            ls_resultados=[]
            lista_temp=[]
            for aparta in resultados: # recorre la lista de apartamentos ya buscados por el precio 
                lista_temp= aparta[0].split(";") # Convierte las facilidades en una lista
                ls_resultados.append(lista_temp)
                lista_temp=[]
            resultados=sorted(ls_resultados, key=lambda aparta: int(aparta[5]))  
        return resultados

    

    def lista_favoritos(self, nom_usa,apartamento):
        archi=open(nom_usa + "_favoritos.txt",'a')
        archi.write(str(apartamento))
        archi.write("\n")
        archi.close()
        # Crear archivo con el nombre del usuario_favoritos
        #escribe el apartamento selecionada en el app como favorito

if __name__ == '__main__':
	app.run(debug=True)
    
